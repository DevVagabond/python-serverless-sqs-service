from handlers.producer.producer import producer

producer = producer
