from handlers.producer.producer import producer
from handlers.consumer.consumer import consumer

producer = producer
consumer = consumer
